.. FRR documentation master file, created by
   sphinx-quickstart on Wed Jan 31 12:00:55 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2

   frr
   frr-bfdd
   frr-bgpd
   frr-eigrpd
   frr-isisd
   frr-fabricd
   frr-ldpd
   frr-nhrpd
   frr-ospf6d
   frr-ospfclient
   frr-ospfd
   frr-pimd
   frr-pbrd
   frr-ripd
   frr-ripngd
   frr-sharpd
   frr-staticd
   frr-watchfrr
   frr-zebra
   frr-vrrpd
   mtracebis
   vtysh
